import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

interface CategoryInputProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  unit: string;
  placeholder?: string;
  testId?: string;
}

export function CategoryInput({
  label,
  value,
  onChange,
  unit,
  placeholder,
  testId,
}: CategoryInputProps) {
  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium">{label}</Label>
      <div className="relative">
        <Input
          type="number"
          value={value || ""}
          onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
          placeholder={placeholder || "0"}
          className="font-mono text-right pr-16"
          min="0"
          step="any"
          data-testid={testId}
        />
        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground pointer-events-none">
          {unit}
        </span>
      </div>
    </div>
  );
}
