import { Card } from "@/components/ui/card";
import { TrendingDown, TrendingUp } from "lucide-react";

interface KPICardProps {
  label: string;
  value: string | number;
  change?: number;
  trend?: "up" | "down" | "neutral";
  suffix?: string;
  testId?: string;
}

export function KPICard({ label, value, change, trend, suffix, testId }: KPICardProps) {
  return (
    <Card className="p-6">
      <p className="text-sm font-medium text-muted-foreground mb-2">{label}</p>
      <div className="flex items-baseline gap-2">
        <p className="text-3xl font-bold font-mono" data-testid={testId}>
          {value}
          {suffix && <span className="text-xl text-muted-foreground ml-1">{suffix}</span>}
        </p>
      </div>
      {change !== undefined && (
        <div className="flex items-center gap-1 mt-2">
          {trend === "down" ? (
            <TrendingDown className="h-4 w-4 text-primary" />
          ) : trend === "up" ? (
            <TrendingUp className="h-4 w-4 text-destructive" />
          ) : null}
          <span className={`text-sm font-semibold ${
            trend === "down" ? "text-primary" : 
            trend === "up" ? "text-destructive" : 
            "text-muted-foreground"
          }`}>
            {change > 0 ? "+" : ""}{change.toFixed(1)}%
          </span>
        </div>
      )}
    </Card>
  );
}
