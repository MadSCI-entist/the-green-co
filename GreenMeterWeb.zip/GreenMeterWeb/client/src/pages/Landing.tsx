import { Button } from "@/components/ui/button";
import { BarChart3, TrendingDown, Users, Leaf } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative h-[500px] bg-gradient-to-br from-primary/20 via-background to-background flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(34,197,94,0.1),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(34,197,94,0.05),transparent_50%)]" />
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Leaf className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">Carbon Emissions Tracking</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
            Measure, Compare, Reduce
          </h1>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
            Track your logistics carbon footprint, benchmark against industry leaders, and take action with data-driven insights.
          </p>
          
          <Button 
            size="lg" 
            className="text-base px-8 py-6 h-auto"
            onClick={() => window.location.href = "/api/login"}
            data-testid="button-login"
          >
            Get Started
          </Button>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-8 rounded-xl border bg-card hover-elevate transition-colors">
            <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
              <BarChart3 className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Interactive Calculator</h3>
            <p className="text-muted-foreground leading-relaxed">
              Input your activity data across multiple categories and instantly see baseline vs optimized emissions with visual comparisons.
            </p>
          </div>

          <div className="p-8 rounded-xl border bg-card hover-elevate transition-colors">
            <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Green Score Leaderboard</h3>
            <p className="text-muted-foreground leading-relaxed">
              Compare your performance with industry peers using our proprietary Green Score that rewards efficiency and renewable adoption.
            </p>
          </div>

          <div className="p-8 rounded-xl border bg-card hover-elevate transition-colors">
            <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
              <TrendingDown className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Optimization Insights</h3>
            <p className="text-muted-foreground leading-relaxed">
              Get actionable recommendations on EV adoption, route optimization, and operational changes to reduce your carbon footprint.
            </p>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to make an impact?</h2>
        <p className="text-lg text-muted-foreground mb-8">
          Join leading logistics companies in the journey toward carbon neutrality.
        </p>
        <Button 
          size="lg" 
          variant="default"
          onClick={() => window.location.href = "/api/login"}
          data-testid="button-cta-login"
        >
          Start Tracking Now
        </Button>
      </div>
    </div>
  );
}
