import { useQuery } from "@tanstack/react-query";
import { KPICard } from "@/components/KPICard";
import { Card } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import type { EmissionRecord } from "@shared/schema";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";

const CHART_COLORS = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))", "hsl(var(--chart-4))", "hsl(var(--chart-5))"];

export default function Dashboard() {
  const { data: latestRecord, isLoading } = useQuery<EmissionRecord>({
    queryKey: ["/api/dashboard/latest"],
  });

  if (isLoading) {
    return (
      <div className="p-8 space-y-8">
        <div>
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
      </div>
    );
  }

  if (!latestRecord) {
    return (
      <div className="p-8">
        <div className="max-w-2xl mx-auto text-center py-12">
          <h2 className="text-2xl font-semibold mb-4">No Calculations Yet</h2>
          <p className="text-muted-foreground mb-6">
            Start by calculating your carbon emissions to see your dashboard.
          </p>
          <Button onClick={() => window.location.href = "/calculator"} data-testid="button-go-calculator">
            Go to Calculator
          </Button>
        </div>
      </div>
    );
  }

  const baselinePieData = [
    { name: "Cars", value: latestRecord.baselineCars, color: CHART_COLORS[0] },
    { name: "Trucks", value: latestRecord.baselineTrucks, color: CHART_COLORS[1] },
    { name: "Planes", value: latestRecord.baselinePlanes, color: CHART_COLORS[2] },
    { name: "Forklifts", value: latestRecord.baselineForklifts, color: CHART_COLORS[3] },
    { name: "Heating", value: latestRecord.baselineHeating, color: CHART_COLORS[4] },
    { name: "Lighting/IT", value: latestRecord.baselineLightingCoolingIt, color: CHART_COLORS[0] },
    { name: "Subcontractors", value: latestRecord.baselineSubcontractors, color: CHART_COLORS[1] },
  ].filter(item => item.value > 0);

  const optimizedPieData = [
    { name: "Cars", value: latestRecord.optimizedCars, color: CHART_COLORS[0] },
    { name: "Trucks", value: latestRecord.optimizedTrucks, color: CHART_COLORS[1] },
    { name: "Planes", value: latestRecord.optimizedPlanes, color: CHART_COLORS[2] },
    { name: "Forklifts", value: latestRecord.optimizedForklifts, color: CHART_COLORS[3] },
    { name: "Heating", value: latestRecord.optimizedHeating, color: CHART_COLORS[4] },
    { name: "Lighting/IT", value: latestRecord.optimizedLightingCoolingIt, color: CHART_COLORS[0] },
    { name: "Subcontractors", value: latestRecord.optimizedSubcontractors, color: CHART_COLORS[1] },
  ].filter(item => item.value > 0);

  const barData = [
    {
      name: "Baseline",
      value: latestRecord.baselineTotal,
      fill: "hsl(var(--destructive))",
    },
    {
      name: "Optimized",
      value: latestRecord.optimizedTotal,
      fill: "hsl(var(--primary))",
    },
  ];

  const reductionPercent = ((latestRecord.baselineTotal - latestRecord.optimizedTotal) / latestRecord.baselineTotal) * 100;

  return (
    <div className="p-4 md:p-8 space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Carbon Dashboard</h1>
          <p className="text-muted-foreground">
            Your latest emission analysis and optimization results
          </p>
        </div>
        <Button variant="outline" size="sm" data-testid="button-download">
          <Download className="h-4 w-4 mr-2" />
          Download Report
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <KPICard
          label="Baseline Emissions"
          value={latestRecord.baselineTotal.toFixed(1)}
          suffix="tons CO₂e"
          testId="kpi-baseline"
        />
        <KPICard
          label="Optimized Emissions"
          value={latestRecord.optimizedTotal.toFixed(1)}
          suffix="tons CO₂e"
          trend="down"
          change={-reductionPercent}
          testId="kpi-optimized"
        />
        <KPICard
          label="Reduction Achieved"
          value={reductionPercent.toFixed(1)}
          suffix="%"
          trend="down"
          testId="kpi-reduction"
        />
      </div>

      {/* Reduction Summary */}
      <Card className="p-6 bg-primary/5 border-primary/20">
        <p className="text-base leading-relaxed" data-testid="text-summary">
          <span className="font-semibold">
            Emissions reduced by {reductionPercent.toFixed(0)}%
          </span>
          {" "}({latestRecord.baselineTotal.toFixed(1)} → {latestRecord.optimizedTotal.toFixed(1)} tons CO₂e)
        </p>
      </Card>

      {/* Pie Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="p-8">
          <h3 className="text-xl font-semibold mb-6">Baseline Emissions by Category</h3>
          <ResponsiveContainer width="100%" height={320}>
            <PieChart>
              <Pie
                data={baselinePieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry) => `${entry.name}: ${entry.value.toFixed(1)}t`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {baselinePieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => `${value.toFixed(2)} tons CO₂e`} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-8">
          <h3 className="text-xl font-semibold mb-6">Optimized Emissions by Category</h3>
          <ResponsiveContainer width="100%" height={320}>
            <PieChart>
              <Pie
                data={optimizedPieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry) => `${entry.name}: ${entry.value.toFixed(1)}t`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {optimizedPieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => `${value.toFixed(2)} tons CO₂e`} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Bar Chart */}
      <Card className="p-8">
        <h3 className="text-xl font-semibold mb-6">Total Emissions Comparison</h3>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={barData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
            <YAxis stroke="hsl(var(--muted-foreground))" label={{ value: 'tons CO₂e', angle: -90, position: 'insideLeft' }} />
            <Tooltip formatter={(value: number) => `${value.toFixed(2)} tons CO₂e`} />
            <Bar dataKey="value" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
