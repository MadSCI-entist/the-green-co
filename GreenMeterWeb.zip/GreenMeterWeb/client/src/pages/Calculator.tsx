import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CategoryInput } from "@/components/CategoryInput";
import { EmissionSlider } from "@/components/EmissionSlider";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { Calculator as CalculatorIcon, RotateCcw } from "lucide-react";
import type { EmissionInput } from "@shared/schema";
import { isUnauthorizedError } from "@/lib/authUtils";

const initialState: EmissionInput = {
  carKm: 0,
  truckKm: 0,
  planeHours: 0,
  forkliftHours: 0,
  heatingKwh: 0,
  lightingCoolingItKwh: 0,
  subcontractorsTons: 0,
  evShare: 0,
  kmReduction: 0,
  planeLoadFactor: 100,
};

export default function Calculator() {
  const [inputs, setInputs] = useState<EmissionInput>(initialState);
  const { toast } = useToast();

  const calculateMutation = useMutation({
    mutationFn: async (data: EmissionInput) => {
      return await apiRequest("POST", "/api/calculator/calculate", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/latest"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leaderboard"] });
      toast({
        title: "Calculation Complete",
        description: "Your emissions have been calculated successfully.",
      });
      window.location.href = "/";
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Calculation Failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleReset = () => {
    setInputs(initialState);
  };

  const handleCalculate = () => {
    calculateMutation.mutate(inputs);
  };

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Carbon Calculator</h1>
        <p className="text-muted-foreground">
          Input your activity data and optimization parameters to calculate emissions
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Section */}
        <div className="space-y-6">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-6">Activity Data</h2>
            <div className="space-y-4">
              <CategoryInput
                label="Cars"
                value={inputs.carKm}
                onChange={(val) => setInputs({ ...inputs, carKm: val })}
                unit="km"
                testId="input-car-km"
              />
              <CategoryInput
                label="Trucks"
                value={inputs.truckKm}
                onChange={(val) => setInputs({ ...inputs, truckKm: val })}
                unit="km"
                testId="input-truck-km"
              />
              <CategoryInput
                label="Cargo Planes"
                value={inputs.planeHours}
                onChange={(val) => setInputs({ ...inputs, planeHours: val })}
                unit="hours"
                testId="input-plane-hours"
              />
              <CategoryInput
                label="Forklifts"
                value={inputs.forkliftHours}
                onChange={(val) => setInputs({ ...inputs, forkliftHours: val })}
                unit="hours"
                testId="input-forklift-hours"
              />
              <CategoryInput
                label="Heating"
                value={inputs.heatingKwh}
                onChange={(val) => setInputs({ ...inputs, heatingKwh: val })}
                unit="kWh"
                testId="input-heating-kwh"
              />
              <CategoryInput
                label="Lighting / Cooling / IT"
                value={inputs.lightingCoolingItKwh}
                onChange={(val) => setInputs({ ...inputs, lightingCoolingItKwh: val })}
                unit="kWh"
                testId="input-lighting-kwh"
              />
              <CategoryInput
                label="Subcontractors"
                value={inputs.subcontractorsTons}
                onChange={(val) => setInputs({ ...inputs, subcontractorsTons: val })}
                unit="tons CO₂"
                testId="input-subcontractors"
              />
            </div>
          </Card>
        </div>

        {/* Optimization Controls */}
        <div className="space-y-6">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-6">Optimization Controls</h2>
            <div className="space-y-6">
              <EmissionSlider
                label="Electric Vehicle (EV) Share for Cars"
                value={inputs.evShare}
                onChange={(val) => setInputs({ ...inputs, evShare: val })}
                helperText="Percentage of car fleet that is electric"
                testId="slider-ev-share"
              />
              <EmissionSlider
                label="Distance Reduction (Better Routing)"
                value={inputs.kmReduction}
                onChange={(val) => setInputs({ ...inputs, kmReduction: val })}
                helperText="Percentage reduction in total kilometers traveled"
                testId="slider-km-reduction"
              />
              <EmissionSlider
                label="Plane Load Factor"
                value={inputs.planeLoadFactor}
                onChange={(val) => setInputs({ ...inputs, planeLoadFactor: val })}
                helperText="Average cargo capacity utilization"
                testId="slider-load-factor"
              />
            </div>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button
              onClick={handleCalculate}
              disabled={calculateMutation.isPending}
              className="flex-1"
              size="lg"
              data-testid="button-calculate"
            >
              <CalculatorIcon className="h-4 w-4 mr-2" />
              {calculateMutation.isPending ? "Calculating..." : "Calculate"}
            </Button>
            <Button
              onClick={handleReset}
              variant="outline"
              size="lg"
              data-testid="button-reset"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          </div>

          {/* Emission Factors Reference */}
          <Card className="p-6 bg-muted/50">
            <h3 className="text-sm font-semibold mb-3">Emission Factors</h3>
            <div className="space-y-1 text-xs text-muted-foreground">
              <div className="flex justify-between">
                <span>Cars</span>
                <span className="font-mono">0.18 kg CO₂/km</span>
              </div>
              <div className="flex justify-between">
                <span>Trucks</span>
                <span className="font-mono">0.90 kg CO₂/km</span>
              </div>
              <div className="flex justify-between">
                <span>Planes</span>
                <span className="font-mono">9000 kg CO₂/hr</span>
              </div>
              <div className="flex justify-between">
                <span>Forklifts</span>
                <span className="font-mono">4.0 kg CO₂/hr</span>
              </div>
              <div className="flex justify-between">
                <span>Heating</span>
                <span className="font-mono">0.20 kg CO₂/kWh</span>
              </div>
              <div className="flex justify-between">
                <span>Lighting/IT</span>
                <span className="font-mono">0.42 kg CO₂/kWh</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
