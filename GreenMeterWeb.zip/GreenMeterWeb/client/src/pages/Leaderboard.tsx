import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";

interface LeaderboardEntry {
  userId: string;
  companyName: string;
  sector: string;
  greenScore: number;
  co2Emissions: number;
  totalDistance: number;
  loadEfficiency: number;
  renewableShare: number;
  rank: number;
}

export default function Leaderboard() {
  const { user } = useAuth();
  const { data: leaderboard, isLoading } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard"],
  });

  if (isLoading) {
    return (
      <div className="p-8 space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  const getMedalIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-5 w-5 text-yellow-500" />;
      case 2:
        return <Trophy className="h-5 w-5 text-gray-400" />;
      case 3:
        return <Trophy className="h-5 w-5 text-amber-600" />;
      default:
        return null;
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Green Score Leaderboard</h1>
        <p className="text-muted-foreground">
          Compare your performance with industry peers using the Green Score metric
        </p>
      </div>

      {/* Formula Card */}
      <Card className="p-6 bg-primary/5 border-primary/20">
        <h3 className="text-sm font-semibold mb-2">Green Score Formula</h3>
        <p className="text-sm text-muted-foreground font-mono mb-3">
          Green Score = Load Efficiency × (1 + R) / (CO₂ emissions (tons) / Total Distance (km))
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          <div>
            <span className="font-medium">Load Efficiency:</span>
            <p className="text-muted-foreground">0–1 (e.g., 0.8 = 80%)</p>
          </div>
          <div>
            <span className="font-medium">R:</span>
            <p className="text-muted-foreground">Renewable/EV Share (0–1)</p>
          </div>
          <div>
            <span className="font-medium">CO₂e:</span>
            <p className="text-muted-foreground">Total annual emissions</p>
          </div>
          <div>
            <span className="font-medium">Distance:</span>
            <p className="text-muted-foreground">Total km traveled</p>
          </div>
        </div>
      </Card>

      {/* Leaderboard Table */}
      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16 text-center">Rank</TableHead>
              <TableHead>Company</TableHead>
              <TableHead>Sector</TableHead>
              <TableHead className="text-right">Green Score</TableHead>
              <TableHead className="text-right">CO₂e (tons)</TableHead>
              <TableHead className="text-right">Distance (km)</TableHead>
              <TableHead className="text-right">Load Eff.</TableHead>
              <TableHead className="text-right">Renewable</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {!leaderboard || leaderboard.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-12 text-muted-foreground">
                  No companies on the leaderboard yet. Complete your profile and calculator to join!
                </TableCell>
              </TableRow>
            ) : (
              leaderboard.map((entry) => {
                const isCurrentUser = entry.userId === user?.id;
                return (
                  <TableRow
                    key={entry.userId}
                    className={isCurrentUser ? "bg-primary/5 border-l-4 border-l-primary" : ""}
                    data-testid={isCurrentUser ? "row-current-user" : `row-user-${entry.rank}`}
                  >
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-2">
                        {getMedalIcon(entry.rank)}
                        <span className="font-semibold">{entry.rank}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{entry.companyName}</span>
                        {isCurrentUser && (
                          <Badge variant="secondary" className="text-xs">You</Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{entry.sector}</TableCell>
                    <TableCell className="text-right">
                      <span className="font-mono font-semibold text-primary" data-testid={`score-${entry.rank}`}>
                        {entry.greenScore.toFixed(2)}
                      </span>
                    </TableCell>
                    <TableCell className="text-right font-mono">{entry.co2Emissions.toFixed(1)}</TableCell>
                    <TableCell className="text-right font-mono">{entry.totalDistance.toLocaleString()}</TableCell>
                    <TableCell className="text-right font-mono">{(entry.loadEfficiency * 100).toFixed(0)}%</TableCell>
                    <TableCell className="text-right font-mono">{(entry.renewableShare * 100).toFixed(0)}%</TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </Card>

      {/* Legend */}
      <Card className="p-6 bg-muted/30">
        <h3 className="text-sm font-semibold mb-3">Understanding Green Score</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          A higher Green Score indicates better sustainability performance. The score rewards companies with
          efficient load utilization, higher renewable/EV adoption, and lower emissions per distance traveled.
          Companies with the best combination of these factors rank at the top.
        </p>
      </Card>
    </div>
  );
}
