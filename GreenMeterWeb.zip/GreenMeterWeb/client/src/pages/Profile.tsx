import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import type { CompanyProfile, InsertCompanyProfile } from "@shared/schema";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Building2, Save } from "lucide-react";

const SECTORS = [
  "Logistics",
  "Manufacturing",
  "Retail",
  "Technology",
  "Healthcare",
  "Energy",
  "Construction",
  "Transportation",
  "Other",
];

export default function Profile() {
  const { toast } = useToast();
  const [formData, setFormData] = useState<Omit<InsertCompanyProfile, 'userId'>>({
    companyName: "",
    sector: "",
    employees: 0,
    totalDistance: 0,
    loadEfficiency: 0.8,
    renewableShare: 0,
  });

  const { data: profile, isLoading } = useQuery<CompanyProfile>({
    queryKey: ["/api/profile"],
  });

  useEffect(() => {
    if (profile) {
      setFormData({
        companyName: profile.companyName,
        sector: profile.sector,
        employees: profile.employees,
        totalDistance: profile.totalDistance,
        loadEfficiency: profile.loadEfficiency,
        renewableShare: profile.renewableShare,
      });
    }
  }, [profile]);

  const saveMutation = useMutation({
    mutationFn: async (data: Omit<InsertCompanyProfile, 'userId'>) => {
      // Server will use authenticated userId, don't send it from client
      return await apiRequest("POST", "/api/profile", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leaderboard"] });
      toast({
        title: "Profile Saved",
        description: "Your company profile has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Save Failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  if (isLoading) {
    return (
      <div className="p-8 space-y-4 max-w-2xl mx-auto">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-2xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Company Profile</h1>
        <p className="text-muted-foreground">
          Set up your company information for accurate Green Score calculations
        </p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit}>
        <Card className="p-6 space-y-6">
          <div className="space-y-2">
            <Label htmlFor="companyName">Company Name *</Label>
            <Input
              id="companyName"
              value={formData.companyName}
              onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
              placeholder="Acme Logistics Inc."
              required
              data-testid="input-company-name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="sector">Industry Sector *</Label>
            <Select
              value={formData.sector}
              onValueChange={(val) => setFormData({ ...formData, sector: val })}
              required
            >
              <SelectTrigger data-testid="select-sector">
                <SelectValue placeholder="Select sector" />
              </SelectTrigger>
              <SelectContent>
                {SECTORS.map((sector) => (
                  <SelectItem key={sector} value={sector}>
                    {sector}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="employees">Number of Employees *</Label>
            <Input
              id="employees"
              type="number"
              value={formData.employees || ""}
              onChange={(e) => setFormData({ ...formData, employees: parseInt(e.target.value) || 0 })}
              placeholder="200"
              min="1"
              required
              data-testid="input-employees"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="totalDistance">Total Annual Distance (km) *</Label>
            <Input
              id="totalDistance"
              type="number"
              value={formData.totalDistance || ""}
              onChange={(e) => setFormData({ ...formData, totalDistance: parseFloat(e.target.value) || 0 })}
              placeholder="500000"
              min="0"
              step="any"
              required
              className="font-mono"
              data-testid="input-total-distance"
            />
            <p className="text-xs text-muted-foreground">
              Total distance traveled by all vehicles annually
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="loadEfficiency">Average Load Efficiency *</Label>
            <div className="flex items-center gap-4">
              <Input
                id="loadEfficiency"
                type="number"
                value={formData.loadEfficiency}
                onChange={(e) => setFormData({ ...formData, loadEfficiency: parseFloat(e.target.value) || 0 })}
                placeholder="0.8"
                min="0"
                max="1"
                step="0.01"
                required
                className="font-mono"
                data-testid="input-load-efficiency"
              />
              <span className="text-sm text-muted-foreground whitespace-nowrap">
                ({(formData.loadEfficiency * 100).toFixed(0)}% full)
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              Average cargo capacity utilization (0 = empty, 1 = fully loaded)
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="renewableShare">Renewable / EV Share *</Label>
            <div className="flex items-center gap-4">
              <Input
                id="renewableShare"
                type="number"
                value={formData.renewableShare}
                onChange={(e) => setFormData({ ...formData, renewableShare: parseFloat(e.target.value) || 0 })}
                placeholder="0.3"
                min="0"
                max="1"
                step="0.01"
                required
                className="font-mono"
                data-testid="input-renewable-share"
              />
              <span className="text-sm text-muted-foreground whitespace-nowrap">
                ({(formData.renewableShare * 100).toFixed(0)}%)
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              Proportion of fleet using renewable energy or electric vehicles
            </p>
          </div>

          <div className="flex gap-4 pt-4">
            <Button
              type="submit"
              disabled={saveMutation.isPending}
              className="flex-1"
              size="lg"
              data-testid="button-save-profile"
            >
              <Save className="h-4 w-4 mr-2" />
              {saveMutation.isPending ? "Saving..." : "Save Profile"}
            </Button>
          </div>
        </Card>
      </form>

      {/* Info Card */}
      <Card className="p-6 bg-muted/30">
        <div className="flex gap-3">
          <Building2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
          <div className="space-y-2">
            <h3 className="text-sm font-semibold">Why This Matters</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Your company profile is used to calculate your Green Score and position you on the leaderboard.
              Accurate data ensures fair comparisons with industry peers and helps identify improvement opportunities.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
