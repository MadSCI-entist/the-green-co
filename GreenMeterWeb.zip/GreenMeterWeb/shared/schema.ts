// Green Meter Schema - referencing javascript_log_in_with_replit and javascript_database blueprints
import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  integer,
  doublePrecision,
  text,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Company profiles table
export const companyProfiles = pgTable("company_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  companyName: varchar("company_name").notNull(),
  sector: varchar("sector").notNull(), // e.g., "Logistics", "Manufacturing"
  employees: integer("employees").notNull(),
  totalDistance: doublePrecision("total_distance").notNull(), // km per year
  loadEfficiency: doublePrecision("load_efficiency").notNull(), // 0-1 (e.g., 0.8 = 80%)
  renewableShare: doublePrecision("renewable_share").notNull(), // 0-1 (e.g., 0.3 = 30%)
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const companyProfilesRelations = relations(companyProfiles, ({ one }) => ({
  user: one(users, {
    fields: [companyProfiles.userId],
    references: [users.id],
  }),
}));

export const insertCompanyProfileSchema = createInsertSchema(companyProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  employees: z.number().int().positive(),
  totalDistance: z.number().positive(),
  loadEfficiency: z.number().min(0).max(1),
  renewableShare: z.number().min(0).max(1),
});

export type InsertCompanyProfile = z.infer<typeof insertCompanyProfileSchema>;
export type CompanyProfile = typeof companyProfiles.$inferSelect;

// Emission records table - stores calculation results
export const emissionRecords = pgTable("emission_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  
  // Input data
  carKm: doublePrecision("car_km").notNull().default(0),
  truckKm: doublePrecision("truck_km").notNull().default(0),
  planeHours: doublePrecision("plane_hours").notNull().default(0),
  forkliftHours: doublePrecision("forklift_hours").notNull().default(0),
  heatingKwh: doublePrecision("heating_kwh").notNull().default(0),
  lightingCoolingItKwh: doublePrecision("lighting_cooling_it_kwh").notNull().default(0),
  subcontractorsTons: doublePrecision("subcontractors_tons").notNull().default(0),
  
  // Optimization controls
  evShare: doublePrecision("ev_share").notNull().default(0), // 0-100 (percentage)
  kmReduction: doublePrecision("km_reduction").notNull().default(0), // 0-100 (percentage)
  planeLoadFactor: doublePrecision("plane_load_factor").notNull().default(100), // 0-100 (percentage)
  
  // Calculated emissions (in tons CO2e)
  baselineCars: doublePrecision("baseline_cars").notNull(),
  baselineTrucks: doublePrecision("baseline_trucks").notNull(),
  baselinePlanes: doublePrecision("baseline_planes").notNull(),
  baselineForklifts: doublePrecision("baseline_forklifts").notNull(),
  baselineHeating: doublePrecision("baseline_heating").notNull(),
  baselineLightingCoolingIt: doublePrecision("baseline_lighting_cooling_it").notNull(),
  baselineSubcontractors: doublePrecision("baseline_subcontractors").notNull(),
  baselineTotal: doublePrecision("baseline_total").notNull(),
  
  optimizedCars: doublePrecision("optimized_cars").notNull(),
  optimizedTrucks: doublePrecision("optimized_trucks").notNull(),
  optimizedPlanes: doublePrecision("optimized_planes").notNull(),
  optimizedForklifts: doublePrecision("optimized_forklifts").notNull(),
  optimizedHeating: doublePrecision("optimized_heating").notNull(),
  optimizedLightingCoolingIt: doublePrecision("optimized_lighting_cooling_it").notNull(),
  optimizedSubcontractors: doublePrecision("optimized_subcontractors").notNull(),
  optimizedTotal: doublePrecision("optimized_total").notNull(),
  
  createdAt: timestamp("created_at").defaultNow(),
});

export const emissionRecordsRelations = relations(emissionRecords, ({ one }) => ({
  user: one(users, {
    fields: [emissionRecords.userId],
    references: [users.id],
  }),
}));

export const insertEmissionRecordSchema = createInsertSchema(emissionRecords).omit({
  id: true,
  createdAt: true,
});

export type InsertEmissionRecord = z.infer<typeof insertEmissionRecordSchema>;
export type EmissionRecord = typeof emissionRecords.$inferSelect;

// Emission calculation input schema
export const emissionInputSchema = z.object({
  carKm: z.number().min(0),
  truckKm: z.number().min(0),
  planeHours: z.number().min(0),
  forkliftHours: z.number().min(0),
  heatingKwh: z.number().min(0),
  lightingCoolingItKwh: z.number().min(0),
  subcontractorsTons: z.number().min(0),
  evShare: z.number().min(0).max(100),
  kmReduction: z.number().min(0).max(100),
  planeLoadFactor: z.number().min(0).max(100),
});

export type EmissionInput = z.infer<typeof emissionInputSchema>;

// Emission factors (kg CO2 per unit)
export const EMISSION_FACTORS = {
  CARS: 0.18,        // kg CO2 per km
  TRUCKS: 0.90,      // kg CO2 per km
  PLANES: 9000,      // kg CO2 per hour
  FORKLIFTS: 4.0,    // kg CO2 per hour
  HEATING: 0.20,     // kg CO2 per kWh
  LIGHTING_COOLING_IT: 0.42, // kg CO2 per kWh
  EV_FACTOR: 0.3,    // EV emissions are 30% of regular cars
} as const;
